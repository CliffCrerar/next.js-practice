import withPost from '../../lib/with-post'

export default withPost({
  title: 'Learn Next.js website is awesome',
  content: `
To start learning Next.js, simply visit: <https://learnnextjs.com>
`
})
