import Layout from '../components/MyLayout.js'

export default function() {
  return (
    <Layout>
      <p>This is the about page</p>
    </Layout>
  )
}
