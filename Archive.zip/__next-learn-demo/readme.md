# nextjs.org/learn demo content

This repository is meant to be used with the Next.js tutorial on https://nextjs.org/learn.

## Setup

There are two ways to start using this repository:

- [**Download a zipped version of this repository**](https://github.com/zeit/next-learn-demo/archive/master.zip)

- **Clone the repository with git** by running the following command:
  ```bash
  git clone git@github.com:zeit/next-learn-demo.git
  ```
