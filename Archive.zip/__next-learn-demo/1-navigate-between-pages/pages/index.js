export default function Index() {
  return (
    <div>
      <p>Hello Next.js</p>
    </div>
  )
}
