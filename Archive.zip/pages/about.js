export default function About(){
    return(
        <div>
        	<p>This the about page</p>
        </div>
    )
}