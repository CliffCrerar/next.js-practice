const index = ()=>(
    <div>
        <p>Hello Next.js</p>
    </div>
)

export default index;